import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { pool } from './db.js';
import { requireAuth, requireAdmin, signToken } from './auth.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

function normalizeIdentity(value = '') {
  return value.trim().toLowerCase();
}

function parseJson(value, fallback = null) {
  if (value == null) return fallback;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return fallback; }
}

app.get('/api/health', async (_req, res) => {
  const [rows] = await pool.query('SELECT 1 AS ok');
  res.json({ ok: rows[0].ok === 1 });
});

app.post('/api/register', async (req, res) => {
  const { username, email, password } = req.body || {};
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Vyplň všechna pole.' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  try {
    await pool.query(
      `INSERT INTO users (username, email, password_hash, role, approved, active, attempts_allowed, created_by_admin)
       VALUES (?, ?, ?, 'user', FALSE, FALSE, 1, FALSE)`,
      [username.trim(), normalizeIdentity(email), passwordHash]
    );
    res.status(201).json({ message: 'Registrace byla vytvořena. Čeká na schválení administrátorem.' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Uživatel nebo e-mail už existuje.' });
    }
    throw error;
  }
});

app.post('/api/login', async (req, res) => {
  const { identity, password } = req.body || {};
  if (!identity || !password) {
    return res.status(400).json({ error: 'Chybí přihlašovací údaje.' });
  }

  const [rows] = await pool.query(
    'SELECT * FROM users WHERE LOWER(email) = ? OR LOWER(username) = ? LIMIT 1',
    [normalizeIdentity(identity), normalizeIdentity(identity)]
  );

  const user = rows[0];
  if (!user) return res.status(401).json({ error: 'Neplatné přihlašovací údaje.' });
  if (!user.approved || !user.active) return res.status(403).json({ error: 'Účet není aktivní nebo schválený.' });

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Neplatné přihlašovací údaje.' });

  const token = signToken(user);
  res.json({ token, user: { id: user.id, username: user.username, email: user.email, role: user.role, approved: !!user.approved, active: !!user.active, attemptsAllowed: user.attempts_allowed } });
});

app.post('/api/reset-password', async (req, res) => {
  const { identity, newPassword } = req.body || {};
  if (!identity || !newPassword) return res.status(400).json({ error: 'Chybí identita nebo nové heslo.' });

  const [rows] = await pool.query(
    'SELECT id FROM users WHERE LOWER(email) = ? OR LOWER(username) = ? LIMIT 1',
    [normalizeIdentity(identity), normalizeIdentity(identity)]
  );
  const user = rows[0];
  if (!user) return res.status(404).json({ error: 'Uživatel nebyl nalezen.' });

  const passwordHash = await bcrypt.hash(newPassword, 10);
  await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [passwordHash, user.id]);
  res.json({ message: 'Heslo bylo změněno.' });
});

app.get('/api/me', requireAuth, async (req, res) => {
  const [rows] = await pool.query('SELECT id, username, email, role, approved, active, attempts_allowed FROM users WHERE id = ?', [req.user.id]);
  res.json(rows[0]);
});

app.get('/api/admin/users', requireAuth, requireAdmin, async (_req, res) => {
  const [rows] = await pool.query('SELECT id, username, email, role, approved, active, attempts_allowed, created_at FROM users ORDER BY created_at DESC');
  res.json(rows);
});

app.post('/api/admin/users/:id/approve', requireAuth, requireAdmin, async (req, res) => {
  await pool.query('UPDATE users SET approved = TRUE, active = TRUE WHERE id = ?', [req.params.id]);
  res.json({ message: 'Uživatel byl schválen.' });
});

app.post('/api/admin/users/:id/toggle-active', requireAuth, requireAdmin, async (req, res) => {
  await pool.query('UPDATE users SET active = NOT active WHERE id = ?', [req.params.id]);
  res.json({ message: 'Stav uživatele byl změněn.' });
});

app.post('/api/admin/users/:id/allow-attempt', requireAuth, requireAdmin, async (req, res) => {
  await pool.query('UPDATE users SET attempts_allowed = attempts_allowed + 1 WHERE id = ?', [req.params.id]);
  res.json({ message: 'Další pokus byl povolen.' });
});

app.get('/api/questions', requireAuth, async (_req, res) => {
  const [rows] = await pool.query('SELECT id, category, type, question, options_json, explanation, points, image_url FROM questions ORDER BY category, id');
  res.json(rows.map(q => ({ ...q, options: parseJson(q.options_json, []), options_json: undefined })));
});

app.post('/api/admin/questions', requireAuth, requireAdmin, async (req, res) => {
  const { id, category, type, question, options = [], correctAnswers = [], explanation = '', points = 1, image = null } = req.body || {};
  if (!id || !category || !type || !question || !Array.isArray(correctAnswers) || !correctAnswers.length) {
    return res.status(400).json({ error: 'Chybí povinná data otázky.' });
  }

  await pool.query(
    `INSERT INTO questions (id, category, type, question, options_json, correct_answers_json, explanation, points, image_url)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, category, type, question, Array.isArray(options) && options.length ? JSON.stringify(options) : null, JSON.stringify(correctAnswers), explanation, points, image]
  );

  res.status(201).json({ message: 'Otázka byla přidána.' });
});

app.get('/api/tests', requireAuth, async (req, res) => {
  const [rows] = await pool.query(
    `SELECT id, user_id, status, score, pass, allow_correct_answers, started_at, expires_at, finished_at, created_at
     FROM tests WHERE user_id = ? ORDER BY created_at DESC`,
    [req.user.id]
  );
  res.json(rows);
});

app.post('/api/tests/start', requireAuth, async (req, res) => {
  const [users] = await pool.query('SELECT * FROM users WHERE id = ?', [req.user.id]);
  const user = users[0];
  if (!user || user.role !== 'user') return res.status(403).json({ error: 'Test může spustit jen běžný uživatel.' });

  const [activeTests] = await pool.query('SELECT id FROM tests WHERE user_id = ? AND status = "probíhá" LIMIT 1', [req.user.id]);
  if (activeTests.length) return res.status(409).json({ error: 'Jeden test už probíhá.' });

  const [tests] = await pool.query('SELECT COUNT(*) AS total FROM tests WHERE user_id = ?', [req.user.id]);
  if (tests[0].total >= user.attempts_allowed) {
    return res.status(403).json({ error: 'Další pokus musí povolit administrátor.' });
  }

  const startedAt = new Date();
  const expiresAt = new Date(startedAt.getTime() + 45 * 60 * 1000);
  const [result] = await pool.query(
    'INSERT INTO tests (user_id, status, score, pass, allow_correct_answers, started_at, expires_at) VALUES (?, "probíhá", 0, FALSE, FALSE, ?, ?)',
    [req.user.id, startedAt, expiresAt]
  );

  const [questions] = await pool.query('SELECT * FROM questions ORDER BY RAND() LIMIT 30');
  let order = 1;
  for (const q of questions) {
    await pool.query(
      `INSERT INTO test_questions (test_id, question_id, question_order, points, options_json)
       VALUES (?, ?, ?, ?, ?)`,
      [result.insertId, q.id, order++, q.points, q.options_json]
    );
  }

  res.status(201).json({ message: 'Test byl vytvořen.', testId: result.insertId, expiresAt });
});

app.get('/api/tests/:id', requireAuth, async (req, res) => {
  const [tests] = await pool.query('SELECT * FROM tests WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  const test = tests[0];
  if (!test) return res.status(404).json({ error: 'Test nebyl nalezen.' });

  const [rows] = await pool.query(
    `SELECT tq.id, tq.question_order, tq.points, tq.user_answer_json, tq.is_correct, tq.evaluated,
            q.id AS question_id, q.category, q.type, q.question, q.options_json, q.correct_answers_json, q.explanation, q.image_url
     FROM test_questions tq
     JOIN questions q ON q.id = tq.question_id
     WHERE tq.test_id = ?
     ORDER BY tq.question_order`,
    [req.params.id]
  );

  res.json({
    ...test,
    questions: rows.map(r => ({
      id: r.question_id,
      category: r.category,
      type: r.type,
      question: r.question,
      options: parseJson(r.options_json, []),
      correctAnswers: test.allow_correct_answers ? parseJson(r.correct_answers_json, []) : undefined,
      explanation: r.explanation,
      image: r.image_url,
      points: r.points,
      userAnswer: parseJson(r.user_answer_json, r.type === 'multiple' ? [] : ''),
      isCorrect: r.is_correct,
      evaluated: !!r.evaluated,
      order: r.question_order,
      testQuestionId: r.id
    }))
  });
});

app.post('/api/tests/:id/answers/:testQuestionId', requireAuth, async (req, res) => {
  const { answer } = req.body || {};
  await pool.query(
    `UPDATE test_questions tq
     JOIN tests t ON t.id = tq.test_id
     SET tq.user_answer_json = ?
     WHERE tq.id = ? AND tq.test_id = ? AND t.user_id = ? AND t.status = 'probíhá'`,
    [JSON.stringify(answer), req.params.testQuestionId, req.params.id, req.user.id]
  );
  res.json({ message: 'Odpověď uložena.' });
});

app.post('/api/tests/:id/finish', requireAuth, async (req, res) => {
  const [tests] = await pool.query('SELECT * FROM tests WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  const test = tests[0];
  if (!test) return res.status(404).json({ error: 'Test nebyl nalezen.' });
  if (test.status !== 'probíhá') return res.status(400).json({ error: 'Test už je ukončen.' });

  const [rows] = await pool.query(
    `SELECT tq.id AS test_question_id, tq.points, tq.user_answer_json, q.type, q.correct_answers_json
     FROM test_questions tq
     JOIN questions q ON q.id = tq.question_id
     WHERE tq.test_id = ?`,
    [req.params.id]
  );

  let score = 0;
  for (const row of rows) {
    const answer = parseJson(row.user_answer_json, row.type === 'multiple' ? [] : '');
    const correct = parseJson(row.correct_answers_json, []);

    let isCorrect = false;
    if (row.type === 'single' || row.type === 'open') {
      isCorrect = correct.includes(String(answer).trim());
    } else {
      const a = Array.isArray(answer) ? [...answer].sort() : [];
      const b = [...correct].sort();
      isCorrect = a.length === b.length && a.every((v, i) => v === b[i]);
    }

    if (isCorrect) score += row.points;

    await pool.query('UPDATE test_questions SET is_correct = ?, evaluated = TRUE WHERE id = ?', [isCorrect, row.test_question_id]);
  }

  const pass = score >= 36;
  await pool.query(
    'UPDATE tests SET score = ?, pass = ?, status = "dokončený", finished_at = NOW() WHERE id = ?',
    [score, pass, req.params.id]
  );

  res.json({ message: 'Test byl odevzdán.', score, pass });
});

app.post('/api/answer-requests', requireAuth, async (req, res) => {
  const { testId } = req.body || {};
  if (!testId) return res.status(400).json({ error: 'Chybí ID testu.' });

  await pool.query('INSERT INTO answer_requests (user_id, test_id, status) VALUES (?, ?, "čeká")', [req.user.id, testId]);
  res.status(201).json({ message: 'Žádost byla odeslána.' });
});

app.get('/api/admin/answer-requests', requireAuth, requireAdmin, async (_req, res) => {
  const [rows] = await pool.query(
    `SELECT ar.id, ar.status, ar.created_at, ar.user_id, ar.test_id, u.username
     FROM answer_requests ar
     JOIN users u ON u.id = ar.user_id
     ORDER BY ar.created_at DESC`
  );
  res.json(rows);
});

app.post('/api/admin/answer-requests/:id/approve', requireAuth, requireAdmin, async (req, res) => {
  const [rows] = await pool.query('SELECT test_id FROM answer_requests WHERE id = ?', [req.params.id]);
  const request = rows[0];
  if (!request) return res.status(404).json({ error: 'Žádost nebyla nalezena.' });

  await pool.query('UPDATE answer_requests SET status = "schváleno" WHERE id = ?', [req.params.id]);
  await pool.query('UPDATE tests SET allow_correct_answers = TRUE WHERE id = ?', [request.test_id]);
  res.json({ message: 'Žádost byla schválena.' });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Chyba serveru.' });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`Server běží na http://localhost:${port}`);
});
