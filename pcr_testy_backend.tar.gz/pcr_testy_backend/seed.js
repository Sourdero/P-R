import { pool } from './db.js';
import { seedQuestions } from './questions.js';

async function run() {
  for (const q of seedQuestions) {
    await pool.query(
      `INSERT INTO questions (id, category, type, question, options_json, correct_answers_json, explanation, points, image_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         category = VALUES(category),
         type = VALUES(type),
         question = VALUES(question),
         options_json = VALUES(options_json),
         correct_answers_json = VALUES(correct_answers_json),
         explanation = VALUES(explanation),
         points = VALUES(points),
         image_url = VALUES(image_url)`,
      [
        q.id,
        q.category,
        q.type,
        q.question,
        q.options ? JSON.stringify(q.options) : null,
        JSON.stringify(q.correctAnswers),
        q.explanation || null,
        q.points || 1,
        q.image || null
      ]
    );
  }

  console.log(`Nahráno ${seedQuestions.length} otázek.`);
  await pool.end();
}

run().catch(async (err) => {
  console.error(err);
  await pool.end();
  process.exit(1);
});
