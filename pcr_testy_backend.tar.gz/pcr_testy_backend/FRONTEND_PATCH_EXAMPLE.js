// Příklad, jak nahradit localStorage volání API voláním.
// Registrace:
async function registerUser() {
  const username = document.getElementById('regUsername').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;

  const response = await fetch('http://localhost:3000/api/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password })
  });

  const data = await response.json();
  if (!response.ok) return alert(data.error || 'Registrace selhala.');

  alert(data.message);
  showScreen('login');
}

// Přihlášení:
async function loginUser() {
  const identity = document.getElementById('loginIdentity').value.trim();
  const password = document.getElementById('loginPassword').value;

  const response = await fetch('http://localhost:3000/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identity, password })
  });

  const data = await response.json();
  if (!response.ok) return alert(data.error || 'Přihlášení selhalo.');

  localStorage.setItem('token', data.token);
  localStorage.setItem('currentUser', JSON.stringify(data.user));
  showScreen(data.user.role === 'admin' ? 'admin' : 'user');
}
