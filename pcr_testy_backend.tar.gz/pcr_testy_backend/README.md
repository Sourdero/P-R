# PCR Testy backend (Node.js + MySQL)

## Co je hotové
- registrace
- přihlášení přes JWT
- reset hesla
- schválení uživatelů administrátorem
- povolení dalšího pokusu
- otázky v databázi
- vytvoření testu
- ukládání odpovědí
- odevzdání testu a výpočet bodů
- žádost o zobrazení správných odpovědí

## 1. Instalace
```bash
npm install
```

## 2. Databáze
1. Otevři phpMyAdmin nebo MySQL klient.
2. Spusť soubor `schema.sql`.
3. Zkopíruj `.env.example` na `.env` a uprav přihlašovací údaje.

## 3. Naplnění otázek
```bash
node seed.js
```

## 4. Spuštění serveru
```bash
npm start
```

Server poběží na:
```bash
http://localhost:3000
```

## 5. Admin účet
- e-mail: `admin@pcr.local`
- heslo: `admin123`

## 6. Co je potřeba ještě udělat ve frontendu
Tvůj původní `index.html` ukládá vše do `localStorage`. To je potřeba přepsat na API volání přes `fetch()`.
Pro start máš ukázku v souboru `FRONTEND_PATCH_EXAMPLE.js`.

## 7. Doporučený další krok
- přesunout celý `seedQuestions` z HTML do `seed.js`
- přepsat `registerUser`, `loginUser`, `resetPassword`, `startTest`, `saveProgress`, `finishTest`, `renderAdmin` na práci s API
- hashovat hesla jen na backendu
- nikdy neposílat `correctAnswers` běžnému uživateli, dokud admin neschválí žádost
