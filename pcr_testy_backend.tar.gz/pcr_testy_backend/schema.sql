CREATE DATABASE IF NOT EXISTS pcr_testy CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;
USE pcr_testy;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  approved BOOLEAN NOT NULL DEFAULT FALSE,
  active BOOLEAN NOT NULL DEFAULT FALSE,
  attempts_allowed INT NOT NULL DEFAULT 1,
  created_by_admin BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS questions (
  id VARCHAR(50) PRIMARY KEY,
  category VARCHAR(100) NOT NULL,
  type ENUM('single','multiple','open') NOT NULL,
  question TEXT NOT NULL,
  options_json JSON NULL,
  correct_answers_json JSON NOT NULL,
  explanation TEXT,
  points INT NOT NULL DEFAULT 1,
  image_url TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  status ENUM('probíhá','dokončený','zrušený') NOT NULL DEFAULT 'probíhá',
  score INT NOT NULL DEFAULT 0,
  pass BOOLEAN NOT NULL DEFAULT FALSE,
  allow_correct_answers BOOLEAN NOT NULL DEFAULT FALSE,
  started_at DATETIME NOT NULL,
  expires_at DATETIME NOT NULL,
  finished_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_tests_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS test_questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  test_id INT NOT NULL,
  question_id VARCHAR(50) NOT NULL,
  question_order INT NOT NULL,
  points INT NOT NULL,
  options_json JSON NULL,
  user_answer_json JSON NULL,
  is_correct BOOLEAN NULL,
  evaluated BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT fk_test_questions_test FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE,
  CONSTRAINT fk_test_questions_question FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
  UNIQUE KEY uq_test_question_order (test_id, question_order)
);

CREATE TABLE IF NOT EXISTS answer_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  test_id INT NOT NULL,
  status ENUM('čeká','schváleno','zamítnuto') NOT NULL DEFAULT 'čeká',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_answer_requests_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_answer_requests_test FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE
);

INSERT INTO users (username, email, password_hash, role, approved, active, attempts_allowed, created_by_admin)
VALUES (
  'admin',
  'admin@pcr.local',
  '$2a$10$0xjMZ6nTn4f7h6mNQ0ce1O6CY9eA1b7R4dp6YxM8JxgK43i6W0n6G',
  'admin',
  TRUE,
  TRUE,
  99,
  TRUE
)
ON DUPLICATE KEY UPDATE email = VALUES(email);

-- Heslo pro admin účet: admin123
